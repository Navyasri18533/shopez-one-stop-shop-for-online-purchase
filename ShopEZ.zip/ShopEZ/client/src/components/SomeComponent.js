import axios from '../api/axios'; // use the custom axios instance

// axios.get('/api/your-endpoint') will now go to http://localhost:6003/api/your-endpoint